fx_version 'cerulean' -- NE PAS TOUCHER
games {'gta5'} -- NE PAS TOUCHER

author = 'MFA Concept'

--- MFA UTILS AND DEPENDENCYS (DONT TOUCH)
client_scripts {
    "@mfa_menu/dependency/rageui/menumanager.lua",
    "example_rageui_like.lua"
}