local test = Menu:createMenu("menu_test", "Mon titre", "Sous titre 1", "mfa_banniere.jpg", true, false, nil, nil)
local SubmenuTest = Menu:createMenu("Sub_test", "Mon titre Sub", "Sous titre 2", "mfa_banniere.jpg", true, false, "menu_test",nil)

function mainMenu()
    test:isVisible(0, function()
        test:separator("Mon Separator")
        test:button("Mon button standard", "", "Ma descritption", "Mon rightlabel", "", function(Hovered, Selected)
            if Hovered then
                print("Je suis sur mon button")
            end
            if (Selected) then
                print("J'ai cliqué sur mon button")
            end
        end)
        test:button("Mon button Submenu", "", "Ma descritption", "Mon rightlabel", "", function(Hovered, Selected)
            if Hovered then
                print("Je suis sur mon button")
            end
            if (Selected) then
                print("J'ai cliqué sur mon button")
                --J'appel la function de mon sous menu:
                subMenu()
            end
        end, SubmenuTest, false)
        test:listbox("leftLabel", "", "Ma description", {"Absolute", "JustGod", "Et l'autre"}, function(Hovered, Selected, onChange, index)
            if Selected then
                if index == "Absolute" then
                    print("Il sais pas dev")
                elseif index == "JustGod" then
                    print("C'est un beau gosse")
                elseif index == "Et l'autre" then
                    print("C'est JL Power askip")
                end
            end
        end)
    end)
end

function subMenu()
    SubmenuTest:isVisible(0, function()
        SubmenuTest:separator("Mon Separator Sous Menu")
        SubmenuTest:button("Mon button standard", "", "Ma descritption Sous Menu", "Mon rightlabel", "", function(Hovered, Selected)
            if Hovered then
                print("Je suis sur mon button")
            end
            if Selected then
                print("J'ai cliqué sur mon button")
            end
        end)
    end)
    SubmenuTest:refresh()
end

RegisterCommand("testmenu", function()
    mainMenu()
    Menu.openMenu(test)
end)